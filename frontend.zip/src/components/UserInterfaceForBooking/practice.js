
export default function Practice()
{

return(
<body>

  <footer class="footer">
    <div class="footer-div-1 fonte">
		<div>Angry Restaurant</div>
		<div>Swiggy</div>
	</div>
	<div className="footer-div-2 fonte">
	    <div>Restaurant </div>
		<div>About</div>
		<div>Career</div>
		<div>Team</div>
		<div>Restaurant One</div>
		<div>Restaurant Instamart</div>
		<div>Restaurant Geniue</div>

	</div>
	<div className="footer-div-3 fonte">
		<div className="footer-div-3-child-one">
	    <div>Contact us</div>
		<div>Help & Support</div>
		<div>Partner with Us</div>
		<div>Help & Support</div>
		<div>Help & Support</div>
		<div>Help & Support</div>
		</div>

		<div className="footer-div-3-child-two fonte margina">
		<div>Contact us</div>
		<div>Help & Support</div>
		<div>Partner with Us</div>
		<div>Help & Support</div>
		<div>Help & Support</div>
		<div>Help & Support</div>
		</div>
	</div>
	<div className="footer-div-4 fonte">
		<div>We deliver to:</div>
		<div>Gurogram</div>
		<div>Gwalior</div>
		<div>Indore</div>
		<div>Bhopal</div>
	</div>
	
  </footer>

</body>)
}
