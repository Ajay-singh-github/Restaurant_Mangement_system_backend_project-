// import { AppBar } from "@mui/material";






// export default function FoodBookingforUserInterface()
// {
//     return(<div>
//         <Box sx={{ flexGrow: 1 }}>
//       <AppBar position="static">
//         <Toolbar>
//           <IconButton
//             size="large"
//             edge="start"
//             color="inherit"
//             aria-label="open drawer"
//             sx={{ mr: 2 }}
//           >
//             <MenuIcon />
//           </IconButton>
//           <Typography
//             variant="h6"
//             noWrap
//             component="div"
//             sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
//           >
//             MUI
//           </Typography>
//           <Search>
//             <SearchIconWrapper>
//               <SearchIcon />
//             </SearchIconWrapper>
//             <StyledInputBase
//               placeholder="Search…"
//               inputProps={{ 'aria-label': 'search' }}
//             />
//           </Search>
//         </Toolbar>
//       </AppBar>
//     </Box>
//     </div>)
// }






// import * as React from 'react';
// import { styled, alpha } from '@mui/material/styles';
// import AppBar from '@mui/material/AppBar';
// import Box from '@mui/material/Box';
// import Toolbar from '@mui/material/Toolbar';
// import IconButton from '@mui/material/IconButton';
// import Typography from '@mui/material/Typography';
// import InputBase from '@mui/material/InputBase';
// import MenuIcon from '@mui/icons-material/Menu';
// import SearchIcon from '@mui/icons-material/Search';

// const Search = styled('div')(({ theme }) => ({
//   position: 'relative',
//   borderRadius: theme.shape.borderRadius,
//   backgroundColor: alpha(theme.palette.common.white, 0.15),
//   '&:hover': {
//     backgroundColor: alpha(theme.palette.common.white, 0.25),
//   },
//   marginLeft: 0,
//   width: '100%',
//   [theme.breakpoints.up('sm')]: {
//     marginLeft: theme.spacing(1),
//     width: 'auto',
//   },
// }));

// const SearchIconWrapper = styled('div')(({ theme }) => ({
//   padding: theme.spacing(0, 2),
//   height: '100%',
//   position: 'absolute',
//   pointerEvents: 'none',
//   display: 'flex',
//   alignItems: 'center',
//   justifyContent: 'center',
// }));

// const StyledInputBase = styled(InputBase)(({ theme }) => ({
//   color: 'inherit',
//   width: '100%',
//   '& .MuiInputBase-input': {
//     padding: theme.spacing(1, 1, 1, 0),
//     // vertical padding + font size from searchIcon
//     paddingLeft: `calc(1em + ${theme.spacing(4)})`,
//     transition: theme.transitions.create('width'),
//     [theme.breakpoints.up('sm')]: {
//       width: '12ch',
//       '&:focus': {
//         width: '20ch',
//       },
//     },
//   },
// }));

// export default function  FoodBookingforUserInterface() {
//   return (
//     <div>
//     <div>
//     <Box sx={{ flexGrow: 1 }}>
//       <AppBar position="static" component={"nav"}>
//         <Toolbar>
//           <IconButton
//             size="large"
//             edge="start"
//             color="inherit"
//             aria-label="open drawer"
//             sx={{ mr: 2 }}
//           >
//             <MenuIcon />
//           </IconButton>
//           <Typography
//             variant="h6"
//             noWrap
//             component="div"
//             sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
//           >
//             MUI
//           </Typography>
//           <Search>
//             <SearchIconWrapper>
//               <SearchIcon />
//             </SearchIconWrapper>
//             <StyledInputBase
//               placeholder="Search…"
//               inputProps={{ 'aria-label': 'search' }}
//             />
//           </Search>
//         </Toolbar>
//       </AppBar>
//     </Box>
//     </div>
//     <div>
//     Once upon a time, a farmer had a goose that laid a golden egg every day. The farmer used to sell that egg and earn enough money to meet their family's day-to-day needs. One day, the farmer thought that if he could get more such golden eggs and make a lot of money and become a wealthy person. The farmer decided to cut the goose and remove all the golden eggs from its stomach. As soon as they killed the bird and opened the goose’s stomach, they found no eggs. The foolish farmer realized they had destroyed their last resource out of greed. 

// Moral: Greed destroys your resource.


// 2. The Shepherd Boy and the Wolf
// A shepherd boy in a village used to take his herd of sheep across the fields near the forest. He felt this job was very dull and wanted to have some fun. One day while grazing the sheep, he shouted, "Wolf! Wolf! The wolf is carrying away a lamb!" Farmers working in the nearby fields came running for help but didn’t find any wolf. The boy laughed and replied, "It was just fun. There is no wolf here". 

// The boy played a similar trick repeatedly for many days. After some days, while the shepherd boy was in the field with the herd of sheep, suddenly, a wolf came out from the nearby forest and attacked one of the lambs. The boy was frightened and cried loudly, "Wolf! Wolf! The wolf is carrying a lamb away!" The farmers thought the boy was playing mischief again. So, no one paid attention to him and didn’t come to his help. 

// Moral: No one believes a liar even if they speak the truth once.

// 3. Having a Best Friend: Friendship Moral Stories in English
// Having a best friend by Shaikh Subuhi is one of the best friendship moral stories in English. The story is about two friends who were walking through the desert. During the journey, they argued over something, and one friend slapped the other. The one who got slapped was hurt by this gesture of his best friend but did not react. He quietly wrote in the sand, “Today my best friend slapped me.”

// After some time, they found an oasis and started taking a bath in the lake. Suddenly, the one who had been slapped started drowning. Then his friend came to his rescue and saved him. After he recovered from the drowning, he engraved “Today my best friend saved my life” on a stone.

// The friend who had slapped earlier and later saved his best friend asked, “After I slapped you, you wrote in the sand, and now, as I saved you, you write on a stone, why?” The other friend replied, “I wrote in on sand because we should not keep the feeling of getting hurt by someone for a long time. But, when someone does something good for us, we must remember it forever like a message engraved on a stone that nothing can erase”.

// Moral: Remember the good things that happen in life, not the bad memories.

// 4. The King’s Painting 
// There was a king with only one leg and one eye but was generous and competent as a ruler. One day while walking in his palace, the king noticed the portraits of his ancestors along the hallway. He also wanted his portrait painted by an artist but was unsure how it would turn out due to his physical abnormalities. The King invited all the painters across the kingdoms and asked who could paint a beautiful picture of him. The painters were confused about how to make a beautiful picture of the King with only one leg and one eye.

// All the painters politely refused to make a painting of the King. Then one young painter came forward and ensured to make a beautiful portrait of the King. After a few days, the young painter unveiled the portrait in the court in which the King was seen sitting on the horse with one leg visible, holding his bow and aiming the arrow with one eye closed. There was no sign of physical deficiencies in the king in the painting. The King was pleased to see that the painter had creatively presented the King’s positive characteristics but not highlighted the abnormalities.

// Moral: Look at the positive aspects of someone without emphasizing the limitations.

// 5. The Pig and the Sheep
// A pig found its way into a meadow where a shepherd was grazing a herd of sheep. The shepherd caught the pig and carried him off toward the butcher shop when it started crying loud and struggled to get free. The sheep told the pig, "The shepherd catches us regularly and drags us off like that, and we don't make any noise." The pig replied, "My case and yours are altogether different; he catches and takes you to shave off the wool, but he wants me to be killed for making the bacon."

// Moral: Don’t compare two situations without understanding them.


// Conclusion
// Children from an early age should develop a strong base of moral values that help them to be good human beings. A moral story must be part of the academic curriculum and parental learning. These learning will have a profound impact on individual lives as well as on society. In the end, we suggest you read at least one new story in English with morals for your kids to teach them good moral values.Once upon a time, a farmer had a goose that laid a golden egg every day. The farmer used to sell that egg and earn enough money to meet their family's day-to-day needs. One day, the farmer thought that if he could get more such golden eggs and make a lot of money and become a wealthy person. The farmer decided to cut the goose and remove all the golden eggs from its stomach. As soon as they killed the bird and opened the goose’s stomach, they found no eggs. The foolish farmer realized they had destroyed their last resource out of greed. 

// Moral: Greed destroys your resource.


// 2. The Shepherd Boy and the Wolf
// A shepherd boy in a village used to take his herd of sheep across the fields near the forest. He felt this job was very dull and wanted to have some fun. One day while grazing the sheep, he shouted, "Wolf! Wolf! The wolf is carrying away a lamb!" Farmers working in the nearby fields came running for help but didn’t find any wolf. The boy laughed and replied, "It was just fun. There is no wolf here". 

// The boy played a similar trick repeatedly for many days. After some days, while the shepherd boy was in the field with the herd of sheep, suddenly, a wolf came out from the nearby forest and attacked one of the lambs. The boy was frightened and cried loudly, "Wolf! Wolf! The wolf is carrying a lamb away!" The farmers thought the boy was playing mischief again. So, no one paid attention to him and didn’t come to his help. 

// Moral: No one believes a liar even if they speak the truth once.

// 3. Having a Best Friend: Friendship Moral Stories in English
// Having a best friend by Shaikh Subuhi is one of the best friendship moral stories in English. The story is about two friends who were walking through the desert. During the journey, they argued over something, and one friend slapped the other. The one who got slapped was hurt by this gesture of his best friend but did not react. He quietly wrote in the sand, “Today my best friend slapped me.”

// After some time, they found an oasis and started taking a bath in the lake. Suddenly, the one who had been slapped started drowning. Then his friend came to his rescue and saved him. After he recovered from the drowning, he engraved “Today my best friend saved my life” on a stone.

// The friend who had slapped earlier and later saved his best friend asked, “After I slapped you, you wrote in the sand, and now, as I saved you, you write on a stone, why?” The other friend replied, “I wrote in on sand because we should not keep the feeling of getting hurt by someone for a long time. But, when someone does something good for us, we must remember it forever like a message engraved on a stone that nothing can erase”.

// Moral: Remember the good things that happen in life, not the bad memories.

// 4. The King’s Painting 
// There was a king with only one leg and one eye but was generous and competent as a ruler. One day while walking in his palace, the king noticed the portraits of his ancestors along the hallway. He also wanted his portrait painted by an artist but was unsure how it would turn out due to his physical abnormalities. The King invited all the painters across the kingdoms and asked who could paint a beautiful picture of him. The painters were confused about how to make a beautiful picture of the King with only one leg and one eye.

// All the painters politely refused to make a painting of the King. Then one young painter came forward and ensured to make a beautiful portrait of the King. After a few days, the young painter unveiled the portrait in the court in which the King was seen sitting on the horse with one leg visible, holding his bow and aiming the arrow with one eye closed. There was no sign of physical deficiencies in the king in the painting. The King was pleased to see that the painter had creatively presented the King’s positive characteristics but not highlighted the abnormalities.

// Moral: Look at the positive aspects of someone without emphasizing the limitations.

// 5. The Pig and the Sheep
// A pig found its way into a meadow where a shepherd was grazing a herd of sheep. The shepherd caught the pig and carried him off toward the butcher shop when it started crying loud and struggled to get free. The sheep told the pig, "The shepherd catches us regularly and drags us off like that, and we don't make any noise." The pig replied, "My case and yours are altogether different; he catches and takes you to shave off the wool, but he wants me to be killed for making the bacon."

// Moral: Don’t compare two situations without understanding them.


// Conclusion
// Children from an early age should develop a strong base of moral values that help them to be good human beings. A moral story must be part of the academic curriculum and parental learning. These learning will have a profound impact on individual lives as well as on society. In the end, we suggest you read at least one new story in English with morals for your kids to teach them good moral values.Once upon a time, a farmer had a goose that laid a golden egg every day. The farmer used to sell that egg and earn enough money to meet their family's day-to-day needs. One day, the farmer thought that if he could get more such golden eggs and make a lot of money and become a wealthy person. The farmer decided to cut the goose and remove all the golden eggs from its stomach. As soon as they killed the bird and opened the goose’s stomach, they found no eggs. The foolish farmer realized they had destroyed their last resource out of greed. 

// Moral: Greed destroys your resource.


// 2. The Shepherd Boy and the Wolf
// A shepherd boy in a village used to take his herd of sheep across the fields near the forest. He felt this job was very dull and wanted to have some fun. One day while grazing the sheep, he shouted, "Wolf! Wolf! The wolf is carrying away a lamb!" Farmers working in the nearby fields came running for help but didn’t find any wolf. The boy laughed and replied, "It was just fun. There is no wolf here". 

// The boy played a similar trick repeatedly for many days. After some days, while the shepherd boy was in the field with the herd of sheep, suddenly, a wolf came out from the nearby forest and attacked one of the lambs. The boy was frightened and cried loudly, "Wolf! Wolf! The wolf is carrying a lamb away!" The farmers thought the boy was playing mischief again. So, no one paid attention to him and didn’t come to his help. 

// Moral: No one believes a liar even if they speak the truth once.

// 3. Having a Best Friend: Friendship Moral Stories in English
// Having a best friend by Shaikh Subuhi is one of the best friendship moral stories in English. The story is about two friends who were walking through the desert. During the journey, they argued over something, and one friend slapped the other. The one who got slapped was hurt by this gesture of his best friend but did not react. He quietly wrote in the sand, “Today my best friend slapped me.”

// After some time, they found an oasis and started taking a bath in the lake. Suddenly, the one who had been slapped started drowning. Then his friend came to his rescue and saved him. After he recovered from the drowning, he engraved “Today my best friend saved my life” on a stone.

// The friend who had slapped earlier and later saved his best friend asked, “After I slapped you, you wrote in the sand, and now, as I saved you, you write on a stone, why?” The other friend replied, “I wrote in on sand because we should not keep the feeling of getting hurt by someone for a long time. But, when someone does something good for us, we must remember it forever like a message engraved on a stone that nothing can erase”.

// Moral: Remember the good things that happen in life, not the bad memories.

// 4. The King’s Painting 
// There was a king with only one leg and one eye but was generous and competent as a ruler. One day while walking in his palace, the king noticed the portraits of his ancestors along the hallway. He also wanted his portrait painted by an artist but was unsure how it would turn out due to his physical abnormalities. The King invited all the painters across the kingdoms and asked who could paint a beautiful picture of him. The painters were confused about how to make a beautiful picture of the King with only one leg and one eye.

// All the painters politely refused to make a painting of the King. Then one young painter came forward and ensured to make a beautiful portrait of the King. After a few days, the young painter unveiled the portrait in the court in which the King was seen sitting on the horse with one leg visible, holding his bow and aiming the arrow with one eye closed. There was no sign of physical deficiencies in the king in the painting. The King was pleased to see that the painter had creatively presented the King’s positive characteristics but not highlighted the abnormalities.

// Moral: Look at the positive aspects of someone without emphasizing the limitations.

// 5. The Pig and the Sheep
// A pig found its way into a meadow where a shepherd was grazing a herd of sheep. The shepherd caught the pig and carried him off toward the butcher shop when it started crying loud and struggled to get free. The sheep told the pig, "The shepherd catches us regularly and drags us off like that, and we don't make any noise." The pig replied, "My case and yours are altogether different; he catches and takes you to shave off the wool, but he wants me to be killed for making the bacon."

// Moral: Don’t compare two situations without understanding them.


// Conclusion
// Children from an early age should develop a strong base of moral values that help them to be good human beings. A moral story must be part of the academic curriculum and parental learning. These learning will have a profound impact on individual lives as well as on society. In the end, we suggest you read at least one new story in English with morals for your kids to teach them good moral values.
//     </div>
// </div>
//   );
// }








import * as React from 'react';
import PropTypes from 'prop-types';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import SearchIcon from '@mui/icons-material/Search';
import { styled, alpha } from '@mui/material/styles';
import InputBase from '@mui/material/InputBase';
import ProductionQuantityLimitsIcon from '@mui/icons-material/ProductionQuantityLimits';
import { Grid } from '@mui/material';
import { makeStyles } from "@mui/styles"
import { hover } from '@testing-library/user-event/dist/hover';
import './styles.css'
import SimpleSlider from './SlickComponent';
import FilterComponent from './FillterComponent';
import ImgMediaCard from './ImgMediaCardComponent';
import { Style } from '@mui/icons-material';
import Footer from './Footer';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import { useState } from 'react';
import { postData } from '../../services/FetchNodeServices';
import Practice from './practice';
import MenuButton from './MenuButton';
import { useNavigate } from 'react-router-dom';



import Snackbar from '@mui/material/Snackbar';
import CloseIcon from '@mui/icons-material/Close';
import { useSelector } from 'react-redux';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';

const useStyles = makeStyles({

})
const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  width: '100%',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));

const drawerWidth = 240;
const navItems = ['Home', 'Cart', 'Contact'];

function  FoodBookingforUserInterface(props) {
  var admin=JSON.parse(localStorage.getItem('ADMIN'))
  var navigate=useNavigate()

  const theme = useTheme();
  const foodOrder = useSelector((state)=>state.orderData)
  const matches_md = useMediaQuery(theme.breakpoints.down('md'));
  const matches_sm = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles()
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [categorydata,setCategoryData]=useState([])
  const [refresh,setRefresh]=useState(false)
  const [categoryid,setCategoryid]=useState('')
  const [valuefilter,setValueFilter]=React.useState('')
  const [veg,setVeg]=useState('')
  const [noveg,setNonVeg]=useState('')
  const [searchvalue,setSearchValue]=useState("")
  const [backresult,setBackResult]=useState()
  const [againcategorydata,setAgainCategoryData]=useState([])
  const [data,setData] = useState([])
  const [count,setCount]=useState(0)
  const [open, setOpen] = React.useState(false);
  const [totaladd,setTotalAdd]=useState('')
  console.log(valuefilter)
  
  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };




 
  
 
 

  const action = (
    <React.Fragment>
      {/* <Button color="secondary" size="small" onClick={handleClose}>
        UNDO
      </Button>
      <IconButton
        size="small"
        aria-label="close"
        color="inherit"
        onClick={handleClose}
      >
        <CloseIcon fontSize="small" />
      </IconButton> */}
    </React.Fragment>
  );
  console.log("i am checking backresult again:",backresult)
  //alert(valuefilter)
  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };
 
  const SearchButton=()=>
  {  
    // if(categoryid.length==0 && searchvalue>0)
    // {
    //   alert("yes yes")
    // }else
    // {}

    
    if(categoryid.length==0 && searchvalue.length>0)
    {
      setOpen(true);
    }else
    {
      console.log("yes")
    }
    
    console.log("ccccccccccccccccccccccccccccccccccc:",categorydata)
    
     var backresult= categorydata.filter((item)=>{
          
      return item.fooditemname.toLowerCase().includes(searchvalue.toLowerCase())
    })
    
    console.log("ddddddddddddddddddddddddddddddddddddddddd:",backresult)
    setBackResult(categorydata)

    if(backresult.length>0 && searchvalue.length!==1)
    {
      setCategoryData(backresult)
    }else
    {
      
      setCategoryData(againcategorydata)
    }


  }

  React.useEffect(function(){
   if(!searchvalue=="" && !categorydata==[])
   {
     SearchButton()
     
   }
  },[searchvalue])


  
  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
      <Typography variant="h6" sx={{ my: 2 }}>
        Welcome to the Hungry Hub Restaurant
      </Typography>
      <Divider />
      <List>
        {navItems.map((item) => (
          <ListItem key={item} disablePadding>
            {item=="Cart"?
            <span style={{width:totaladd>9?"80%":totaladd==0?"71%":'75%'}} onClick={()=>navigate('/cart')}>
            <ListItemButton  sx={{ textAlign: 'end' }} >
            <ListItemText  primary={item} style={{}}/><div style={{fontSize:"20px" ,marginLeft:20,color:'green'}}>{totaladd}</div>
          </ListItemButton></span>:
            <ListItemButton sx={{ textAlign: 'center' }} >
              <ListItemText  primary={item} />
            </ListItemButton>
            }
          </ListItem>
        ))}
      </List>
    </Box>
  );

  const container = window !== undefined ? () => window().document.body : undefined;

  
  const handleImageDataOne=async()=>
  {
    
    
    const result=await postData('restaurants/fetch_category_by_spacific',{categoryid:categoryid,'restaurantid':admin.restaurantid})
    setCategoryData(result.result)
    setAgainCategoryData(result.result)
    
  }


  React.useEffect(function(){
    if(categoryid !=='')
    {
    handleImageDataOne()
    }
  },[categoryid])
  console.log("filter value like no veg:",valuefilter)
   const filterfunction=async(pro)=>
   {
           if(pro=="vegetarian")
            { 
              const result=await postData('restaurants/fetch_fooditem_by_filter',{categoryid:categoryid,'restaurantid':admin.restaurantid,foodtype:valuefilter})
              setCategoryData(result.result)
              
            }else if(pro=="Non vegetarian") 
            {
              const result=await postData('restaurants/fetch_fooditem_by_filter',{categoryid:categoryid,'restaurantid':admin.restaurantid,foodtype:valuefilter})
              setCategoryData(result.result)
            }else if(pro=="300-600")  
            {
              const result=await postData('restaurants/fetch_fooditem_by_filter_result_by_300_600',{categoryid:categoryid,'restaurantid':admin.restaurantid})
              setCategoryData(result.result)
            } 
            else if(pro=="1-300")
            {
              
              const result=await postData('restaurants/fetch_fooditem_by_filter_result_by_1_300',{categoryid:categoryid,'restaurantid':admin.restaurantid})
              setCategoryData(result.result)
            }
           else if(pro=="Low to High")
           {
            const result=await postData('restaurants/fetch_fooditem_by_filter_result_by_1_300',{categoryid:categoryid,'restaurantid':admin.restaurantid})
            setCategoryData(result.result)
           }
              
       
       //select f.*,c.categoryname from fooditems f,category c where f.categoryid=c.categoryid and f.offerprice between 300  and 600 order by f.offerprice asc
       
   }


  // React.useEffect(function(){
  //    filterfunction(valuefilter)
  // },[valuefilter])
 

  const snackbar=()=>{
    return( 

<div>
      
      <Snackbar
        open={open}
        autoHideDuration={1200}
        onClose={handleClose}
        message="Plz Select Category"
        action={action}
      />
    </div>
    )
  }
  return (
    <div>
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar component="nav" style={{background:'white',color:'black'}} >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } ,fontWeight:'bold' , letterSpacing:2}}
          >
            <Grid container>
              <Grid item xs={1} style={{alignItems:'flex-end',display:'flex'}}>
              <img src="restaurant logo for userinterface.png"  className={"hero"} onClick={()=>navigate("/home")}/>
              </Grid>
              <Grid item xs={matches_md?10:8} style={{display:'flex',alignItems:'center',justifyContent:matches_md?'flex-end':'',marginLeft:matches_md?10:''}}>
               Welcome To The Hungry Hub Restaurant 

              </Grid>
            </Grid>
           
          </Typography>
          <Search style={{marginRight:5}}>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
              onChange={(e)=>setSearchValue(e.target.value) }
              //  onChange={handleClick(SlideTransition)}
              //  onClick={handleClick}
            />
          </Search>
          <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
           
              <Button sx={{ color: 'black' ,}} onClick={()=>navigate('/cart')}>
               {totaladd==''? <ProductionQuantityLimitsIcon />:<span><sub style={{}}><ShoppingCartIcon/></sub> <sup style={{color:"green",fontSize:'20px'}}>{totaladd}</sup></span> } {totaladd==0?"Cart":''}
              </Button>
            
          </Box>
        </Toolbar>
      </AppBar>
  
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, // Better open performance on mobile.
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
        >
          {drawer}
        </Drawer>
      
      
    </Box>
     <div style={{marginTop:60}}>
       <SimpleSlider categoryid={categoryid} setCategoryid={setCategoryid} refresh={refresh} setRefresh={setRefresh}/>
     </div>
     {console.log("i am trying show result in console:",categorydata)}
     <div style={{marginTop:60}}>
  
     <div style={{width:'100%',height:'0.5px' , background:"black"}}></div>
        {/* <FilterComponent setValueFilter={setValueFilter} setVeg={setVeg} veg={veg}  setNonVeg={setNonVeg} noveg={noveg} valuefilter={valuefilter}/> */}
        
     </div>
     <div>
      <ImgMediaCard setValueFilter={setValueFilter} setVeg={setVeg} veg={veg}  setNonVeg={setNonVeg} noveg={noveg} valuefilter={valuefilter} totaladd={totaladd} setTotalAdd={setTotalAdd} categorydata={categorydata} setCategoryData={setCategoryData} backresult={backresult}  setBackResult={setBackResult} refresh={refresh} setRefresh={setRefresh}/>
     </div>
     <div>
      {/* <Footer/> */}
      <Practice/>
     
      
     </div>
     
     {snackbar()}
    </div>
  );
}

FoodBookingforUserInterface.propTypes = {
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

export default  FoodBookingforUserInterface;
